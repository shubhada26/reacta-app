'use strict';

module.exports = {
   // At H:30 every 12 hours
   // '30 */12 * * *': generateStats
   // '* * * * *': generateStats
};
