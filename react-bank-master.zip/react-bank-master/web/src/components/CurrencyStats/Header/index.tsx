import React from 'react';
import './style.scss';

const CurrencyStatsHeader = () => <h1>Currency statistics</h1>;

export default CurrencyStatsHeader;
