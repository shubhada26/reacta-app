import * as H from 'history';

export type ButtonTypes = 'button' | 'submit' | 'reset' | undefined;
